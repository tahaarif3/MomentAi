# MomentAI Mobile

Native iOS / Android app for [MomentAI](https://momentai.dev), built with **Capacitor + Vite (vanilla JS)**.

This repository is **separate** from the web/API monolith (`MomentAi`). It talks to the production API over HTTPS only.

```text
src/  →  vite build  →  dist/mobile  →  npx cap sync  →  ios/ android/
```

## Prerequisites

- Node 20+
- Android Studio (Android)
- **macOS + Xcode** for iOS builds and App Store signing (not available on Linux CI alone)
- Backend Phase 0 deployed (`progressToken`, Spaces, `/api/mobile/compatibility`, account deletion)

## Setup

```bash
cp .env.example .env
# set VITE_API_BASE, Supabase, RevenueCat, optional GA4/Sentry

npm install
npm run build
npx cap add android   # once
# on macOS: npx cap add ios
npm run cap:sync
```

## Scripts

| Script | Purpose |
|--------|---------|
| `npm run dev` | Vite dev server |
| `npm run build` | Emit `dist/mobile` |
| `npm run cap:sync` | Build + Capacitor sync |
| `npm run test:unit` | Node unit tests |

## Architecture

- `src/lib/api.js` — API client (`VITE_API_BASE`, Bearer JWT, `progressToken`)
- `src/lib/auth.js` — Supabase PKCE, Preferences storage, Universal Link / `momentai://` callback + `exchangeCodeForSession`
- `src/lib/camera.js` — Camera / Photos permissions, URI → compressed JPEG File
- `src/lib/jobProgress.js` — SSE primary, poll fallback, resume after background
- `src/lib/share.js` — Filesystem temp PNG → Share sheet → delete
- `src/lib/billing.js` — RevenueCat (StoreKit / Play); **no Stripe in native**
- `src/lib/analytics.js` — GA4 `platform` + Sentry (no images/prompts/tokens/email)

Spotify export uses the **server master account**; the app opens the returned playlist URL.

## Deep links

Configure Supabase redirect allowlist:

- `momentai://auth/callback`
- `https://momentai.dev/auth/callback` (Universal / App Links — host `apple-app-site-association` / `assetlinks.json` on the web repo)

## Account deletion

In-app: Account → Delete account → `DELETE /api/auth/account`.  
Public web page (Play policy): https://momentai.dev/delete-account.html

## QA

See [`maestro/README.md`](maestro/README.md) and [`docs/qa-matrix.md`](docs/qa-matrix.md).

## Store submission

See [`docs/store-submission.md`](docs/store-submission.md).
