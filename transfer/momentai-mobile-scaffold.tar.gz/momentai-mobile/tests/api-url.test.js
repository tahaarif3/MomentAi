import { test } from 'node:test';
import assert from 'node:assert/strict';

test('API base env default is production host shape', () => {
  const base = (process.env.VITE_API_BASE || 'https://momentai.dev').replace(/\/$/, '');
  assert.match(base, /^https?:\/\//);
});

test('progress token query encoding', () => {
  const token = 'abc.def';
  const url = `https://momentai.dev/api/playlist/job/1/stream?progressToken=${encodeURIComponent(token)}`;
  assert.ok(url.includes('progressToken=abc.def'));
});
