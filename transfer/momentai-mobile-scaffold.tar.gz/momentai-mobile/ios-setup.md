# iOS project setup (macOS required)

This Linux environment can sync Android only. On a Mac:

```bash
npm install
npm run build
npx cap add ios
npm run cap:sync
npx cap open ios
```

Add to `ios/App/App/Info.plist`:

- `NSCameraUsageDescription` — “MomentAI uses the camera to capture moments for playlists.”
- `NSPhotoLibraryUsageDescription` — “MomentAI needs photo access to choose a moment.”
- URL types: scheme `momentai`
- Associated Domains: `applinks:momentai.dev`

Then archive/sign with your Apple Developer team for TestFlight / App Store.
