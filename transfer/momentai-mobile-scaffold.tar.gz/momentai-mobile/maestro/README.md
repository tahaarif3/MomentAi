# Maestro smoke flows

[Maestro](https://maestro.mobile.dev/) fits Capacitor/vanilla better than Detox.

```bash
# Install Maestro CLI, then with a running emulator/simulator + debug build:
maestro test maestro/smoke.yaml
```

Flows are intentionally shallow until native binaries are produced on CI/Mac.
Physical-device passes for the full matrix are documented in `docs/qa-matrix.md`.
