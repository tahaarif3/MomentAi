import './styles/app.css';
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Browser } from '@capacitor/browser';
import { showScreen, registerScreen } from './app/router.js';
import {
  processImage,
  fetchHistory,
  fetchGeneration,
  deleteGeneration,
  savePlaylist,
  suggestMore,
  regenerate,
  deleteAccount,
  fetchCompatibility
} from './lib/api.js';
import {
  initAuth,
  signInWithPassword,
  signUp,
  signOut,
  resetPassword
} from './lib/auth.js';
import { captureMoment, fileFromInput } from './lib/camera.js';
import { watchJob, resumeActiveJob } from './lib/jobProgress.js';
import { sharePlaylistCard } from './lib/share.js';
import {
  initBilling,
  purchasePremium,
  restorePurchases,
  shouldShowStripeCheckout,
  isNativeBilling
} from './lib/billing.js';
import { initObservability, track, captureError, platformName } from './lib/analytics.js';

const state = {
  user: null,
  stagedFile: null,
  generation: null,
  authMode: 'signin',
  watching: null
};

const $ = (id) => document.getElementById(id);

function setLoader(pct, message) {
  const bar = $('loaderBar');
  const msg = $('loaderMessage');
  if (bar) bar.style.width = `${Math.min(100, Math.max(0, pct))}%`;
  if (msg && message) msg.textContent = message;
}

function openAuthModal() {
  $('authModal').classList.add('open');
}

function closeAuthModal() {
  $('authModal').classList.remove('open');
}

function renderAccount() {
  const el = $('accountSummary');
  if (!state.user) {
    el.textContent = 'Not signed in';
    return;
  }
  const rem = state.user.momentsRemainingToday;
  const limit = state.user.dailyUploadLimit;
  el.textContent = `${state.user.email || state.user.displayName} · ${state.user.tier}` +
    (limit != null ? ` · ${rem}/${limit} moments today` : ' · unlimited');
  $('momentsCounter').textContent =
    state.user.tier === 'premium'
      ? 'Unlimited moments (Plus)'
      : `${rem ?? '—'} free moments left today`;
}

async function refreshHistory() {
  const grid = $('momentsGrid');
  if (!state.user) {
    grid.innerHTML = '<p class="mono">Sign in to see saved moments</p>';
    $('momentsCount').textContent = '0 saved';
    return;
  }
  try {
    const data = await fetchHistory();
    const rows = data.history || [];
    $('momentsCount').textContent = `${rows.length} saved`;
    if (state.user) {
      state.user.momentsRemainingToday = data.remainingToday;
      state.user.dailyUploadLimit = data.dailyUploadLimit;
      renderAccount();
    }
    grid.innerHTML = rows
      .map(
        (m) => `
      <button type="button" class="moment-card" data-id="${m.id}">
        <div class="thumb" style="background-image:url('${(m.display_image || m.image_thumb || '').replace(/'/g, "%27")}')"></div>
        <div class="meta">${escapeHtml(m.emotional_vibe || m.playlist_name || 'Moment')}</div>
      </button>`
      )
      .join('');
    grid.querySelectorAll('.moment-card').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          const full = await fetchGeneration(btn.dataset.id);
          applyGeneration(full);
          showScreen('playlist');
        } catch (err) {
          alert(err.message);
        }
      });
    });
  } catch (err) {
    grid.innerHTML = `<p class="mono">${escapeHtml(err.message)}</p>`;
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function applyGeneration(result) {
  state.generation = {
    id: result.generationId,
    imagePath: result.imagePath,
    metadata: result.metadata,
    tracks: result.tracks || [],
    suggestedTracks: result.suggestedTracks || []
  };
  $('playlistTitle').textContent = result.metadata?.emotionalVibe || 'Your playlist';
  $('playlistMood').textContent = result.metadata?.environmentalContext || '';
  renderTracks();
}

function renderTracks() {
  const tracks = state.generation?.tracks || [];
  const list = $('trackList');
  list.innerHTML = tracks
    .map((t, i) => {
      const art = t.album?.images?.[0]?.url || t.image || '';
      const artist = t.artists?.[0]?.name || t.artist || '';
      return `<div class="track" data-i="${i}">
        <img src="${art}" alt="" />
        <div class="info"><strong>${escapeHtml(t.name)}</strong><span>${escapeHtml(artist)}</span></div>
        <button type="button" class="btn btn-ghost" data-preview="${i}">▶</button>
      </div>`;
    })
    .join('');
  list.querySelectorAll('[data-preview]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const t = tracks[Number(btn.dataset.preview)];
      const audio = $('previewAudio');
      if (t?.preview_url) {
        audio.src = t.preview_url;
        audio.play().catch(() => {});
      } else if (t?.external_urls?.spotify) {
        Browser.open({ url: t.external_urls.spotify });
      }
    });
  });
}

async function beginWithFile(file) {
  state.stagedFile = file;
  const url = URL.createObjectURL(file);
  const preview = $('capturePreview');
  preview.style.backgroundImage = `url('${url}')`;
  preview.textContent = '';
  $('btnGenerate').classList.remove('hidden');
}

async function runGeneration() {
  if (!state.stagedFile) return;
  showScreen('loading');
  setLoader(8, 'Uploading…');
  try {
    const data = await processImage(state.stagedFile, $('customPrompt').value || '');
    if (data.jobId) {
      setLoader(15, 'Reading the light…');
      state.watching = watchJob(data.jobId, data.progressToken, {
        onProgress: (p) => {
          if (p.stage === 'analyzing') setLoader(25, 'Reading the light…');
          else if (p.stage === 'resolving') setLoader(60, 'Matching the mood…');
          else if (p.stage === 'finalizing') setLoader(90, 'Curating tracks…');
        },
        onComplete: (result) => {
          applyGeneration(result);
          showScreen('playlist');
          refreshHistory();
        },
        onError: (err) => {
          track('upload_failed', { reason: 'job' });
          captureError(err);
          alert(err.message || 'Generation failed');
          showScreen('capture');
        }
      });
    } else {
      applyGeneration(data);
      showScreen('playlist');
      refreshHistory();
    }
  } catch (err) {
    track('upload_failed', { reason: err.code || 'http' });
    captureError(err);
    if (err.code === 'DAILY_LIMIT') showScreen('paywall');
    else {
      alert(err.message);
      showScreen('capture');
    }
  }
}

function wireUi() {
  $('btnGoCapture').onclick = () => showScreen('capture');
  $('btnCaptureBack').onclick = () => showScreen('home');
  $('btnPlaylistHome').onclick = () => showScreen('home');
  $('btnPaywallBack').onclick = () => showScreen('home');
  $('btnAccount').onclick = () => showScreen('account');
  $('btnAccountBack').onclick = () => showScreen('home');
  $('btnOpenPaywall').onclick = () => showScreen('paywall');
  $('btnOpenAuth').onclick = () => openAuthModal();
  $('btnAuthClose').onclick = () => closeAuthModal();

  $('btnTakePhoto').onclick = async () => {
    try {
      const file = await captureMoment({ source: 'camera' });
      await beginWithFile(file);
    } catch (err) {
      if (!Capacitor.isNativePlatform()) {
        $('fileInput').click();
        return;
      }
      alert(err.message);
    }
  };

  $('btnPickPhoto').onclick = async () => {
    try {
      if (!Capacitor.isNativePlatform()) {
        $('fileInput').click();
        return;
      }
      const file = await captureMoment({ source: 'photos' });
      await beginWithFile(file);
    } catch (err) {
      alert(err.message);
    }
  };

  $('fileInput').onchange = async (e) => {
    const raw = e.target.files?.[0];
    if (!raw) return;
    try {
      const file = await fileFromInput(raw);
      await beginWithFile(file);
    } catch (err) {
      alert(err.message);
    }
  };

  $('btnGenerate').onclick = runGeneration;

  $('btnSaveSpotify').onclick = async () => {
    if (!state.generation?.tracks?.length) return;
    if (!state.user) {
      openAuthModal();
      return;
    }
    const name = state.generation.metadata?.emotionalVibe || 'MomentAI Playlist';
    try {
      const uris = state.generation.tracks.map((t) => t.uri).filter(Boolean);
      const data = await savePlaylist({
        playlistName: name,
        playlistDescription: state.generation.metadata?.environmentalContext || '',
        trackUris: uris,
        generationId: state.generation.id
      });
      if (data.playlistUrl) {
        await Browser.open({ url: data.playlistUrl });
      }
    } catch (err) {
      alert(err.message);
    }
  };

  $('btnShare').onclick = async () => {
    if (!state.generation) return;
    try {
      await sharePlaylistCard({
        title: state.generation.metadata?.emotionalVibe || 'Your moment',
        moodLine: state.generation.metadata?.environmentalContext || '',
        imageUrl: state.generation.imagePath,
        playlistMeta: 'momentai.dev'
      });
    } catch (err) {
      captureError(err);
      alert(err.message || 'Share failed — check Spaces CORS for remote images.');
    }
  };

  $('btnSuggestMore').onclick = async () => {
    if (!state.generation) return;
    try {
      const excludeTrackIds = state.generation.tracks.map((t) => t.id).filter(Boolean);
      const data = await suggestMore({
        metadata: state.generation.metadata,
        excludeTrackIds,
        customPrompt: $('customPrompt').value || ''
      });
      state.generation.tracks = [...state.generation.tracks, ...(data.tracks || [])].slice(0, 30);
      renderTracks();
    } catch (err) {
      alert(err.message);
    }
  };

  $('btnRegenerate').onclick = async () => {
    if (!state.generation?.id) return;
    if (state.user?.tier !== 'premium') {
      showScreen('paywall');
      return;
    }
    showScreen('loading');
    setLoader(10, 'Reading the light…');
    try {
      const data = await regenerate(state.generation.id);
      if (data.jobId) {
        watchJob(data.jobId, data.progressToken, {
          onProgress: () => setLoader(50, 'Matching the mood…'),
          onComplete: (result) => {
            applyGeneration(result);
            showScreen('playlist');
          },
          onError: (err) => {
            alert(err.message);
            showScreen('playlist');
          }
        });
      } else {
        applyGeneration(data);
        showScreen('playlist');
      }
    } catch (err) {
      if (err.code === 'PLUS_REQUIRED') showScreen('paywall');
      else alert(err.message);
    }
  };

  $('btnSignOut').onclick = async () => {
    await signOut();
    state.user = null;
    renderAccount();
    refreshHistory();
  };

  $('btnDeleteAccount').onclick = async () => {
    if (!state.user) {
      openAuthModal();
      return;
    }
    const ok = confirm('Permanently delete your MomentAI account and history?');
    if (!ok) return;
    try {
      await deleteAccount();
      await signOut();
      state.user = null;
      renderAccount();
      refreshHistory();
      alert('Account deleted.');
      showScreen('home');
    } catch (err) {
      alert(err.message);
    }
  };

  let authMode = 'signin';
  const syncAuthUi = () => {
    $('authTitle').textContent = authMode === 'signin' ? 'Sign in' : 'Sign up';
    $('btnAuthSubmit').textContent = authMode === 'signin' ? 'Sign in' : 'Create account';
  };
  $('btnAuthToggle').onclick = () => {
    authMode = authMode === 'signin' ? 'signup' : 'signin';
    syncAuthUi();
  };
  $('btnAuthSubmit').onclick = async () => {
    const email = $('authEmail').value.trim();
    const password = $('authPassword').value;
    try {
      if (authMode === 'signin') await signInWithPassword(email, password);
      else await signUp(email, password);
      closeAuthModal();
    } catch (err) {
      alert(err.message);
    }
  };
  $('btnAuthReset').onclick = async () => {
    const email = $('authEmail').value.trim();
    if (!email) return alert('Enter your email first');
    try {
      await resetPassword(email);
      alert('Password reset email sent (check inbox).');
    } catch (err) {
      alert(err.message);
    }
  };

  $('btnPurchase').onclick = async () => {
    try {
      const { active } = await purchasePremium();
      alert(active ? 'Premium unlocked!' : 'Purchase finished — syncing entitlement…');
    } catch (err) {
      alert(err.message || 'Purchase unavailable. Configure RevenueCat keys.');
    }
  };
  $('btnRestore').onclick = async () => {
    try {
      const { active } = await restorePurchases();
      track('purchase_restore', { active: !!active });
      alert(active ? 'Purchases restored.' : 'No active subscription found.');
    } catch (err) {
      alert(err.message);
    }
  };

  if (shouldShowStripeCheckout()) {
    $('btnWebCheckout').classList.remove('hidden');
  }

  registerScreen('home', { onShow: () => refreshHistory() });
}

async function boot() {
  initObservability();
  track('app_open', {});

  try {
    const compat = await fetchCompatibility();
    if (compat.forceUpgrade) {
      alert(compat.forceUpgradeMessage || 'Please update MomentAI.');
    }
  } catch {
    /* offline ok */
  }

  if (Capacitor.isNativePlatform()) {
    try {
      await StatusBar.setStyle({ style: Style.Dark });
    } catch {
      /* web */
    }
  }

  wireUi();

  await initAuth({
    onSession: async (user) => {
      state.user = user;
      renderAccount();
      refreshHistory();
      if (user?.id) await initBilling(user.id);
    }
  });

  App.addListener('appStateChange', ({ isActive }) => {
    if (!isActive) return;
    resumeActiveJob({
      onComplete: (result) => {
        applyGeneration(result);
        showScreen('playlist');
      },
      onError: (err) => console.warn('resume job', err.message)
    });
  });

  $('paywallNote').textContent = isNativeBilling()
    ? `Store billing on ${platformName()}. Stripe checkout is web-only.`
    : 'Running in browser — use native build for App Store / Play purchases.';

  showScreen('home');
}

boot().catch((err) => {
  captureError(err);
  console.error(err);
});
