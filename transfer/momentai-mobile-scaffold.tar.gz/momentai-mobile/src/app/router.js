const screens = new Map();
let current = null;

export function registerScreen(name, hooks = {}) {
  screens.set(name, hooks);
}

export function showScreen(name) {
  document.querySelectorAll('[data-screen]').forEach((el) => {
    el.classList.toggle('screen--active', el.dataset.screen === name);
  });
  const prev = current;
  if (prev && screens.get(prev)?.onHide) screens.get(prev).onHide();
  current = name;
  screens.get(name)?.onShow?.();
  window.scrollTo(0, 0);
}

export function currentScreen() {
  return current;
}
