# Store submission notes

## Billing

- Premium unlock in the public native app **must** use StoreKit / Google Play Billing (RevenueCat).
- Do **not** expose Stripe Checkout CTAs in release native builds (`shouldShowStripeCheckout()` is false on native).
- RevenueCat webhook → MomentAi `POST /api/billing/revenuecat` syncs `users.tier`.
- Implement restore purchases (Account / Paywall → Restore).

## Account deletion

- In-app delete + https://momentai.dev/delete-account.html (Google Play).

## Privacy / permissions

Declare camera and photo library usage strings:

- iOS `Info.plist`: `NSCameraUsageDescription`, `NSPhotoLibraryUsageDescription`
- Android: `CAMERA`, read media images as required by target SDK

## Deep links

- Universal Links / App Links preferred; `momentai://` fallback.
- Host AASA / assetlinks on the web domain.

## Crash / analytics

- Sentry DSN + GA4 measurement id via env.
- Never log images, prompts, tokens, or emails.
